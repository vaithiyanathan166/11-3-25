from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from TestLocators.locators import SauceLocators  # ✅ Ensure this line is present

class HomePage:
    def __init__(self, driver):
        self.driver = driver

    def click_menu(self):
        """Click on the menu button."""
        WebDriverWait(self.driver, 15).until(  # ⏳ Increased timeout to 15s
            EC.element_to_be_clickable(SauceLocators.MENU_BUTTON)
        ).click()

    def click_logout(self):
        """Click on the logout button after opening the menu."""
        WebDriverWait(self.driver, 15).until(
            EC.element_to_be_clickable(SauceLocators.LOGOUT_BUTTON)
        ).click()

    def is_login_button_visible(self):
        """Check if login button is visible after logout."""
        return WebDriverWait(self.driver, 15).until(
            EC.visibility_of_element_located(SauceLocators.LOGIN_BUTTON)
        ).is_displayed()

    def is_logout_button_visible(self):
        """Check if logout button is visible after clicking menu."""
        return WebDriverWait(self.driver, 15).until(
            EC.visibility_of_element_located(SauceLocators.LOGOUT_BUTTON)
        ).is_displayed()

    def is_cart_visible(self):
        """Check if the cart button is visible."""
        return WebDriverWait(self.driver, 15).until(
            EC.visibility_of_element_located(SauceLocators.CART_BUTTON)
        ).is_displayed()
