from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class HomePage:
    """Page Object Model for the Home Page (After Login)"""

    def __init__(self, driver):
        self.driver = driver
        self.menu_button = (By.ID, "react-burger-menu-btn")
        self.logout_button = (By.ID, "logout_sidebar_link")
        self.cart_button = (By.CLASS_NAME, "shopping_cart_link")

    def click_menu(self):
        """Click the menu button to open the sidebar"""
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.menu_button)
        ).click()

    def is_logout_button_visible(self):

        """Check if the logout button is visible in the menu."""



    def click_logout(self):
        """Click the logout button from the sidebar"""
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.logout_button)
        ).click()

    def is_logout_button_visible(self):
        """Check if the logout button is visible in the menu"""
        self.click_menu()
        return WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.logout_button)
        ).is_displayed()

    def is_cart_button_visible(self):
        """Check if the cart button is visible on the home page"""
        return WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(self.cart_button)
        ).is_displayed()
