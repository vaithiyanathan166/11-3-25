"""
This File contains all the locators
"""
from selenium.webdriver.common.by import By

class SauceLocators:

    MENU_BUTTON = (By.ID, "react-burger-menu-btn")  # Update if needed
    LOGOUT_BUTTON = (By.ID, "logout_sidebar_link")  # Update if needed
    LOGIN_BUTTON = (By.ID, "login-button")  # Ensure correct
    CART_BUTTON = (By.CLASS_NAME, "shopping_cart_link")  # Ensure correct



   # MENU_BUTTON = (By.ID, "react-burger-menu-btn")  # Update with the correct ID
    #LOGOUT_BUTTON = (By.ID, "logout_sidebar_link")  # Update with the correct ID
    #LOGIN_BUTTON = (By.ID, "login-button")  # Update if different
    #CART_BUTTON = (By.CLASS_NAME, "shopping_cart_link")  # Example, update if needed
#class SauceLocators:
    username_locator = 'user-name' 
    password_locator = 'password'
    loginbutton_locator = 'login-button'