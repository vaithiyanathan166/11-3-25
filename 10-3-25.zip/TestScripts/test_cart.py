import pytest
from pages.home_page import HomePage  # ✅ Corrected import
from TestLocators.locators import SauceLocators
from TestData.data import SauceData
from Utilities.excel_functions import ExcelFunctions
from Utilities.webdriver_setup import get_driver

def test_cart_button_visibility():
    """Verify if the cart button is visible."""
    driver = get_driver()
    try:
        home_page = HomePage(driver)
        assert home_page.is_cart_visible(), "Cart button is not visible"
    finally:
        driver.quit()
