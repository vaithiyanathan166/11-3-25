import pytest
from pages.home_page import HomePage  # ✅ Correct import path
from TestLocators.locators import SauceLocators
from TestData.data import SauceData
from Utilities.excel_functions import ExcelFunctions
from Utilities.webdriver_setup import get_driver

def test_logout():
    """Test if the logout button is functioning."""
    driver = get_driver()
    try:
        home_page = HomePage(driver)
        home_page.click_menu()
        home_page.click_logout()

        # Verify login button is visible after logout
        assert home_page.is_login_button_visible(), "Logout failed"
    except Exception as e:
        driver.save_screenshot("screenshots/test_logout_failure.png")  # Save screenshot for debugging
        raise e
    finally:
        driver.quit()

def test_logout_button_visibility():
    """Check if logout button is visible after clicking the menu."""
    driver = get_driver()
    try:
        home_page = HomePage(driver)
        home_page.click_menu()

        assert home_page.is_logout_button_visible(), "Logout button not visible"
    except Exception as e:
        driver.save_screenshot("screenshots/test_logout_button_visibility_failure.png")  # Save screenshot
        raise e
    finally:
        driver.quit()
def test_logout():
    """Test if the logout button is functioning."""
    driver = get_driver()
    try:
        home_page = HomePage(driver)
        home_page.click_menu()
        home_page.click_logout()
        
        assert home_page.is_login_button_visible(), "Logout failed"
    except Exception as e:
        driver.save_screenshot("screenshots/test_logout_failure.png")  # Save screenshot
        raise e
    finally:
        driver.quit()

def test_logout_button_visibility():
    """Check if logout button is visible after clicking the menu."""
    driver = get_driver()
    try:
        home_page = HomePage(driver)
        home_page.click_menu()
        
        assert home_page.is_logout_button_visible(), "Logout button not visible"
    except Exception as e:
        driver.save_screenshot("screenshots/test_logout_button_visibility_failure.png")  # Save screenshot
        raise e
    finally:
        driver.quit()
