"""
This python class file used to store the data 
"""
class SauceData:
    url = "https://www.saucedemo.com/v1/index.html"
    dashboard_url = "https://www.saucedemo.com/v1/inventory.html"
    excel_file = "C:\\Users\\Vaithees\\Desktop\\SAUCEDDTF\\TestData\\testdata.xlsx"
    sheet_number = "Sheet1"